const mongoose = require("mongoose");

const router = require("express").Router();
const mongodb = require("mongodb");
const User = require("../models/user");
const Company = require("../models/company");
const Vessel = require("../models/vessel");
const inspectionData = require("../models/inspectiondata");
const circularJSON = require("circular-json");

const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const checkAuth = require("../middleware/check-auth");
const { async } = require("rxjs");
const util = require("util");

const { data } = require("jquery");
// const { default: mongoose } = require('mongoose');
const { count } = require("../models/user");

// Signup api
router.post("/signup", (req, res) => {
  bcrypt.hash(req.body.password, 10, (err, hash) => {
    if (err) {
      return res.json({ success: false, message: "Hash Error!" });
    } else {
      const user = new User({
        name: req.body.name,
        email: req.body.email,
        companyName: req.body.companyName,
        phoneno: req.body.phoneno,
        password: hash,
      });

      user
        .save()
        .then((_) => {
          res.json({ success: true, message: "Account has been Created!" });
        })
        .catch((err) => {
          if (err.code === 11000) {
            return res.json({
              success: false,
              message: "Email is already existing! ",
            });
          }
          res.json({ success: false, message: "Authentication Failed" });
        });
    }
  });
});

// login api
router.post("/login", (req, res) => {
  User.find({ email: req.body.email })
    .exec()
    .then((result) => {
      if (result.length < 1) {
        return res.json({ success: false, message: "User not found!" });
      }
      const user = result[0];
      bcrypt.compare(req.body.password, user.password, (err, ret) => {
        if (ret) {
          const payload = {
            userId: user._id,
          };
          const token = jwt.sign(payload, "webBatch");
          return res.json({
            success: true,
            token: token,
            message: "Login Successfull!",
          });
        } else {
          return res.json({
            success: false,
            message: "Password does not match",
          });
        }
      });
    })
    .catch((err) => {
      res.json({ success: false, message: "Authentication Failed!" });
    });
});

//dashboard api(get user)
router.get("/dashboard", checkAuth, (req, res) => {
  const userId = req.userData.userId;
  User.findById(userId)
    .exec()
    .then((result) => {
      res.json({ success: true, data: result });
    })
    .catch((err) => {
      res.json({ success: false, message: "Server error" });
    });
});

// router.post('/postChapter', async (req, res) => {
//     console.log('inside post');

//     const company = new Company({
//         questionName: req.body.questionName,
//         questionDescription: req.body.questionDescription,
//         inspectionGuidance: req.body.inspectionGuidance,
//         expectedEvidence: req.body.expectedEvidence,
//         negativeObservation: req.body.negativeObservation,
//         ism: req.body.ism,
//         tmsa: req.body.tmsa
//     });

//     const val = await data.save();
//     res.json("post successful");
// })

//add company
router.post("/company", async (req, res) => {
  counter.findOneAndUpdate(
    { companyCode: "autoval" },
    { $inc: { companySeq: 1 } },
    { new: true },
    (err, cd) => {
      let seqId;
      if (cd == null) {
        const newVal = new counter({
          companyCode: "autoval",
          companySeq: 1,
        });
        newVal.save();
        seqId = 1;
      } else {
        seqId = cd.companySeq;
      }

      const startDate = req.body.companyStartDate;
      const durationinyears = req.body.companyDuration;
      const duration = durationinyears * 365;
      console.log(duration);
      const endDate = new Date(startDate);
      endDate.setDate(endDate.getDate() + duration);
      const company = new Company({
        companyCode: seqId,
        companyName: req.body.companyName,
        companyAddress1: req.body.companyAddress1,
        companyAddress2: req.body.companyAddress2,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city,
        companyPostalCode: req.body.companyPostalCode,
        companyPersonInCharge: req.body.companyPersonInCharge,
        companyPICemail: req.body.companyPICemail,
        companyAccountHead: req.body.companyAccountHead,
        companyAccountTel: req.body.companyAccountTel,
        companyAccountEmail: req.body.companyAccountEmail,
        companyStartDate: req.body.companyStartDate,
        companyDuration: req.body.companyDuration,
        companyEndDate: endDate,
        companySubscriptionRate: req.body.companySubscriptionRate,
        companyNoOfShips: req.body.companyNoOfShips,
        isEnabled: true,
      });
      company
        .save()
        .then((_) => {
          res.json({
            success: true,
            message: "Company has been created successfully!",
          });
        })
        .catch((err) => {
          res.json(err);
        });
    }
  );
});

//retrieve all comapnies OR retrieve and return a single user
router.get("/fetchcompanies", (req, res) => {
  if (req.query.id) {
    const id = req.query.id;

    Company.findById(id)
      .then((data) => {
        if (!data) {
          res.status(404).send({ message: "Not Found User with id " + id });
        } else {
          res.send(data);
        }
      })
      .catch((err) => {
        res
          .status(500)
          .send({ message: "Error retrieving user with id " + id });
      });
  } else {
    Company.find((err, val) => {
      if (err) {
        console.log(err);
      } else {
        res.json(val);
      }
    });
  }
});

//delete Companies
router.delete("/deletecompany/:id", async (req, res) => {
  try {
    console.log(req.params.id);
    const data = await Company;
    const result = await data.deleteOne({
      _id: new mongodb.ObjectId(req.params.id),
    });
    res.send(result);
  } catch (err) {
    res.send(err);
  }
});

// Get Single Company For putting data into Edit Company Form
router.get("/fetchSingleCompany/:id", (req, res) => {
  Company.findById(req.params.id)
    .then((data) => {
      if (!data) {
        res.status(404).send({ message: "Not Found User with id " + id });
      } else {
        res.send(data);
      }
    })
    .catch((err) => {
      res.status(500).send({ message: "Error retrieving user with id " + id });
    });
});

//Edit Company
router.put("/editCompany/:id", (req, res) => {
  if (!req.body) {
    return res.status(400).send({ message: "Data to update cannot be empty" });
  }
  const id = req.params.id;
  Company.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot Update user with ${id}.Maybe User not found!`,
        });
      } else {
        res.send(data);
      }
    })
    .catch((err) => {
      res.status(500).send({ message: "Error Update user information" });
    });
});

// ------------ VESSELS API ------------------------------//

// counter collection for incrementing ID
const counterSchema = new mongoose.Schema({
  vesselCode: {
    type: String,
  },
  companyCode: {
    type: String,
  },
  vesselSeq: {
    type: Number,
  },
  companySeq: {
    type: Number,
  },
});

const counter = mongoose.model("counter", counterSchema);

// create vessel
router.post("/vessel", (req, res) => {
  counter.findOneAndUpdate(
    { vesselCode: "autoval" },
    { $inc: { vesselSeq: 1 } },
    { new: true },
    (err, cd) => {
      let seqId;
      if (cd == null) {
        const newVal = new counter({
          vesselCode: "autoval",
          vesselSeq: 1,
        });
        newVal.save();
        seqId = 0001;
      } else {
        seqId = cd.vesselSeq;
      }
      const vessel = new Vessel({
        vesselCode: seqId,
        vesselName: req.body.vesselName,
        vesselImo: req.body.vesselImo,
        vesselPostOfRegistry: req.body.vesselPostOfRegistry,
        vesselCallSign: req.body.vesselCallSign,
        vesselGrossTonage: req.body.vesselGrossTonage,
        vesselSumerDeadweight: req.body.vesselSumerDeadweight,
        vesselLengthOverall: req.body.vesselLengthOverall,
        vesselBeam: req.body.vesselBeam,
        vesselDraught: req.body.vesselDraught,
        vesselYearOfBuilt: req.body.vesselYearOfBuilt,
        vesselBuilderYard: req.body.vesselBuilderYard,
        vesselPlaceOfBirth: req.body.vesselPlaceOfBirth,
        vesselClassificationSociety: req.body.vesselClassificationSociety,
        vesselMarineSuperintendent: req.body.vesselMarineSuperintendent,
        vesselTechnicalSuperintendent: req.body.vesselTechnicalSuperintendent,
      });

      vessel
        .save()
        .then((_) => {
          res.json({ success: true, message: "Vessel has been created!" });
        })
        .catch((err) => {
          res.json(err);
        });
    }
  );
});

// Fetch Vessels to put into list
router.get("/fetchvessels", (req, res) => {
  Vessel.find((err, val) => {
    if (err) {
      console.log(err);
    } else {
      res.json(val);
    }
  });
});

// delete vessel
// router.delete('/deletevessel/:id', async (req, res) => {
//     try{
//         console.log(req.params.id);
//         const data = await Vessel;
//         const result = await data.deleteOne({_id: new mongodb.ObjectId(req.params.id)})
//         res.send(result);
//     }
//     catch(err){
//         res.send(err)
//     }

// })

router.delete("/deletevessel/:id", async (req, res) => {
  try {
    console.log(req.params.id);
    const data = await Vessel;
    const result = await data.deleteOne({
      _id: new mongodb.ObjectId(req.params.id),
    });
    res.send(result);
  } catch (err) {
    res.send(err);
  }
});

//get single vessel for putting data into edit vessel form
router.get("/fetchSingleVessel/:id", (req, res) => {
  Vessel.findById(req.params.id)
    .then((data) => {
      if (!data) {
        res.status(404).send({ message: "Not Found Vessel with id " + id });
      } else {
        res.send(data);
      }
    })
    .catch((err) => {
      res.status(500).send({ message: "Error retrieving user with id " });
    });
});

//Edit Vessel
router.put("/editVessel/:id", (req, res) => {
  if (!req.body) {
    return res.status(400).send({ message: "Data to update cannot be empty" });
  }
  const id = req.params.id;
  Vessel.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot Update user with ${id}.Maybe User not found!`,
        });
      } else {
        res.send(data);
      }
    })
    .catch((err) => {
      res.status(500).send({ message: "Error Update user information" });
    });
});

// GET inspection data
router.get("/inspectiondata", (req, res) => {
  inspectionData.find((error, data) => {
    if (error) {
      console.log(error);
    } else {
      res.json(data);
    }
  });
});

// Get current question no
router.post("/fetchCurrentQuestion", async (req, res) => {
  let currentQuestion = req.body.currentQuestion;
  currentQuestion = currentQuestion.split(".");
  nextQuestion =
    currentQuestion[0] +
    "." +
    currentQuestion[1] +
    "." +
    String(Number(currentQuestion[2]) + 1);

  await inspectionData
    .find({
      "Question No": nextQuestion,
    })
    .then((data) => {
      if (!data) {
        res.status(404).send({ message: "No more questions." });
      } else {
        res.send(data);
      }
    })
    .catch((err) => {
      res.status(500).send({ message: "Error retrieving user with id " });
    });
});

module.exports = router;
