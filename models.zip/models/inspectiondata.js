const mongoose = require("mongoose");

const inspectionDataSchema = new mongoose.Schema({
  Chapter: {
    type: String,
    required: true,
  },
  "Section Name": {
    type: String,
    required: true,
  },
  "Question No": {
    type: String,
  },
  QuestionDescription: {
    type: String,
  },
  InspectionGuidance: {
    type: String,
  },
  SuggestedInspectorActions: {
    type: String,
  },
  ExpectedEvidence: {
    type: String,
  },
  PotentialGroundsForANegativeObservation: {
    type: String,
  },
  ISM: {
    type: String,
  },
  TMSA: {
    type: String,
  },
});

module.exports = mongoose.model("inspectionData", inspectionDataSchema);
